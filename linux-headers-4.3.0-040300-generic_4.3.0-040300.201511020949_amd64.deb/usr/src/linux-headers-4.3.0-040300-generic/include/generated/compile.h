/* This file is auto generated, version 201511020949 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201511020949 SMP Mon Nov 2 14:50:44 UTC 2015"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 5.2.1 20151010 (Ubuntu 5.2.1-22ubuntu2) "
